package com.example.finalproject;

public class Beer {


    private String name;
    private String image;
    private String abv;
    private String ph ;
    private String ibu;
    private String description;

    public String getName() {
        return name;
    }

    public void setName(String Name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getAbv() {
        return abv;
    }

    public void setAbv(String abv) {
        this.abv = abv;
    }

    public String getPh() {
        return ph;
    }

    public void setPh(String ph) {
        this.ph = ph;
    }

    public String getIbu() {
        return ibu;
    }

    public void setIbu(String ibu) {
        this.ibu = ibu;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


    public Beer(String abv, String ph, String ibu, String description,String name, String image) {
        this.abv = abv;
        this.ph = ph;
        this.ibu = ibu;
        this.description = description;
        this.name= name;
        this.image = image;
    }


}
